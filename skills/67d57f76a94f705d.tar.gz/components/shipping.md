# shipping

**Kind:** service [derived: edges] [derived: callers]  
**Workload:** Deployment  
**Namespace:** otel-demo  
**Connects:** [quote](quote.md) via sync-call  
**Called by:** [checkout](checkout.md), [frontend](frontend.md)  

```mermaid
flowchart LR
  shipping["shipping"]
  checkout["checkout"] -->|sync-call| shipping
  frontend["frontend"] -->|sync-call| shipping
  shipping -->|sync-call| quote["quote"]
```

## Purpose

Provides shipping cost and shipment handling to frontend and checkout. [derived: callers]

Obtains shipping quotes from quote. [derived: edges] [env: QUOTE_ADDR]

## If it fails

Shipping estimates in frontend and the shipping step of checkout fail, and quote loses its only declared caller. [derived: callers] [derived: edges]

## Connections

- **quote** (sync-call): named by `QUOTE_ADDR` (observed, k8stools)

## Documentation

No documentation page names this component. [derived: docs source]
