# cart

**Kind:** service [derived: edges] [derived: callers]  
**Workload:** Deployment  
**Namespace:** otel-demo  
**Connects:** [flagd](flagd.md) via feature-flags (soft); [valkey-cart](valkey-cart.md) via datastore  
**Called by:** [checkout](checkout.md), [frontend](frontend.md)  

```mermaid
flowchart LR
  cart["cart"]
  cart -.->|feature-flags| flagd["flagd"]
  cart -->|datastore| valkey_cart["valkey-cart"]
  checkout["checkout"] -->|sync-call| cart
  frontend["frontend"] -->|sync-call| cart
```

## Purpose

Holds the shopping cart for frontend and checkout. [derived: callers]

Keeps cart state in valkey-cart. [derived: edges] [env: VALKEY_ADDR]

Reads feature-flag values from flagd. [derived: edges] [env: FLAGD_HOST]

## If it fails

Frontend cart pages and the cart step of checkout fail, so the order path that runs frontend to checkout is interrupted for traffic coming through frontend-proxy. [derived: callers] [derived: edges]

## Connections

- **flagd** (feature-flags, soft): named by `FLAGD_HOST` (observed, k8stools)
- **valkey-cart** (datastore): named by `VALKEY_ADDR` (observed, k8stools)

## Documentation

No documentation page names this component. [derived: docs source]
