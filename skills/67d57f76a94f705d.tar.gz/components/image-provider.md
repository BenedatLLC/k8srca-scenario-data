# image-provider

**Kind:** service [derived: callers]  
**Workload:** Deployment  
**Namespace:** otel-demo  
**Called by:** [frontend-proxy](frontend-proxy.md)  

```mermaid
flowchart LR
  image_provider["image-provider"]
  frontend_proxy["frontend-proxy"] -->|route| image_provider
```

## Purpose

Serves images on a path forwarded by frontend-proxy, its only declared caller. [derived: callers]

## If it fails

The image path of frontend-proxy stops returning content for users of that route, while the proxy continues to serve its other paths. [derived: callers] [derived: edges]

## Documentation

No documentation page names this component. [derived: docs source]
