# email

**Kind:** service [derived: edges] [derived: callers]  
**Workload:** Deployment  
**Namespace:** otel-demo  
**Connects:** [flagd](flagd.md) via feature-flags (soft)  
**Called by:** [checkout](checkout.md)  

```mermaid
flowchart LR
  email["email"]
  checkout["checkout"] -->|sync-call| email
  email -.->|feature-flags| flagd["flagd"]
```

## Purpose

Handles order confirmation requests received from checkout, its only declared caller. [derived: callers]

Reads feature-flag values from flagd. [derived: edges] [env: FLAGD_HOST]

## If it fails

Checkout's email calls fail; no other component calls it. [derived: callers]

## Connections

- **flagd** (feature-flags, soft): named by `FLAGD_HOST` (observed, k8stools)

## Documentation

No documentation page names this component. [derived: docs source]
