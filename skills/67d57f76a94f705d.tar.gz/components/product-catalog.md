# product-catalog

**Kind:** service [derived: edges] [derived: callers]  
**Workload:** Deployment  
**Namespace:** otel-demo  
**Connects:** [flagd](flagd.md) via feature-flags (soft)  
**Called by:** [checkout](checkout.md), [frontend](frontend.md), [recommendation](recommendation.md)  

```mermaid
flowchart LR
  product_catalog["product-catalog"]
  checkout["checkout"] -->|sync-call| product_catalog
  frontend["frontend"] -->|sync-call| product_catalog
  product_catalog -.->|feature-flags| flagd["flagd"]
  recommendation["recommendation"] -->|sync-call| product_catalog
```

## Purpose

Supplies product data to frontend, checkout and recommendation. [derived: callers]

Reads feature-flag values from flagd. [derived: edges] [env: FLAGD_HOST]

## If it fails

Frontend product pages, the catalog lookups in checkout and the product data recommendation depends on all fail. [derived: callers] [derived: edges]

## Connections

- **flagd** (feature-flags, soft): named by `FLAGD_HOST` (observed, k8stools)

## Documentation

No documentation page names this component. [derived: docs source]
