# ad

**Kind:** service [derived: callers]  
**Workload:** Deployment  
**Namespace:** otel-demo  
**Called by:** [frontend](frontend.md)  

```mermaid
flowchart LR
  ad["ad"]
  frontend["frontend"] -->|sync-call| ad
```

## Purpose

Serves advertisements to frontend, its only declared caller. [derived: callers]

## If it fails

Frontend's ad calls fail; no other component calls it. [derived: callers]

## Documentation

No documentation page names this component. [derived: docs source]
