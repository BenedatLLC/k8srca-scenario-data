# postgresql

**Kind:** datastore [derived: edges] [derived: callers]  
**Workload:** Deployment  
**Namespace:** otel-demo  
**Called by:** [accounting](accounting.md)  

```mermaid
flowchart LR
  postgresql["postgresql"]
  accounting["accounting"] -->|datastore| postgresql
```

## Purpose

Persists the data written by accounting, its only declared caller. [derived: callers] [derived: edges]

## If it fails

Accounting's writes fail; no other component connects to it. [derived: callers] [derived: edges]

## Documentation

No documentation page names this component. [derived: docs source]
