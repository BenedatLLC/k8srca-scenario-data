# frontend-proxy

**Kind:** gateway [derived: edges] [derived: callers]  
**Workload:** Deployment  
**Namespace:** otel-demo  
**Connects:** [flagd](flagd.md) via route; [frontend](frontend.md) via route; [image-provider](image-provider.md) via route; [load-generator](load-generator.md) via route  
**Called by:** [load-generator](load-generator.md)  

```mermaid
flowchart LR
  frontend_proxy["frontend-proxy"]
  frontend_proxy -->|route| flagd["flagd"]
  frontend_proxy -->|route| frontend["frontend"]
  frontend_proxy -->|route| image_provider["image-provider"]
  frontend_proxy -->|route| load_generator["load-generator"]
  load_generator["load-generator"] -->|load| frontend_proxy
```

## Purpose

Single entry point of the deployment: it forwards requests to frontend, image-provider, flagd and the load-generator web interface. [derived: edges] [env: FRONTEND_HOST] [env: IMAGE_PROVIDER_HOST] [env: FLAGD_HOST] [env: FLAGD_UI_HOST] [env: LOCUST_WEB_HOST]

It is the target of the synthetic traffic produced by load-generator, its only declared caller. [derived: callers]

## If it fails

Load-generator traffic has no other declared destination, so the shop interface, the image endpoint, the flagd endpoints and the load-generator web interface all become unreachable from outside at once, since each is reached only through this proxy. [derived: callers] [derived: edges]

## Connections

- **flagd** (route): named by `FLAGD_HOST` (observed, k8stools), `FLAGD_UI_HOST` (observed, k8stools)
- **frontend** (route): named by `FRONTEND_HOST` (observed, k8stools)
- **image-provider** (route): named by `IMAGE_PROVIDER_HOST` (observed, k8stools)
- **load-generator** (route): named by `LOCUST_WEB_HOST` (observed, k8stools)

## Documentation

No documentation page names this component. [derived: docs source]
