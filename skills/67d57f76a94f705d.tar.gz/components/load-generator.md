# load-generator

**Kind:** load-generator [derived: edges] [env: LOCUST_HOST]  
**Workload:** Deployment  
**Namespace:** otel-demo  
**Connects:** [flagd](flagd.md) via feature-flags (soft); [frontend-proxy](frontend-proxy.md) via load  
**Called by:** [frontend-proxy](frontend-proxy.md)  

```mermaid
flowchart LR
  load_generator["load-generator"]
  frontend_proxy["frontend-proxy"] -->|route| load_generator
  load_generator -.->|feature-flags| flagd["flagd"]
  load_generator -->|load| frontend_proxy["frontend-proxy"]
```

## Purpose

Produces the synthetic request traffic of the deployment, aimed at frontend-proxy. [derived: edges] [env: LOCUST_HOST]

Reads feature-flag values from flagd to shape its behaviour. [derived: edges] [env: FLAGD_HOST]

Exposes a web interface that frontend-proxy forwards to. [derived: callers]

## If it fails

The exercise traffic through frontend-proxy and the services behind it stops, since no other caller of the proxy is declared. [derived: callers] [derived: edges]

Its web interface, reached only through the frontend-proxy route, stops serving while the proxy keeps serving its other paths. [derived: callers] [derived: edges]

## Connections

- **flagd** (feature-flags, soft): named by `FLAGD_HOST` (observed, k8stools)
- **frontend-proxy** (load): named by `LOCUST_HOST` (observed, k8stools)

## Documentation

No documentation page names this component. [derived: docs source]
