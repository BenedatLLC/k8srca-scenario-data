# accounting

**Kind:** service [derived: edges]  
**Workload:** Deployment  
**Namespace:** otel-demo  
**Connects:** [kafka](kafka.md) via async-event; [postgresql](postgresql.md) via datastore  

```mermaid
flowchart LR
  accounting["accounting"]
  accounting -->|async-event| kafka["kafka"]
  accounting -->|datastore| postgresql["postgresql"]
```

## Purpose

Consumes the order stream from kafka and records it in postgresql. [derived: edges] [env: KAFKA_ADDR] [env: DB_CONNECTION_STRING]

Has no declared callers; it is driven by the kafka stream. [derived: callers] [derived: edges]

## If it fails

No component calls it, so no request path breaks; the order messages on kafka stop being written to postgresql. [derived: callers] [derived: edges]

## Connections

- **kafka** (async-event): named by `KAFKA_ADDR` (observed, k8stools)
- **postgresql** (datastore): named by `DB_CONNECTION_STRING` (observed, k8stools)

## Documentation

No documentation page names this component. [derived: docs source]
