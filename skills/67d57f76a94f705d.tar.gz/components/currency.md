# currency

**Kind:** service [derived: callers]  
**Workload:** Deployment  
**Namespace:** otel-demo  
**Called by:** [checkout](checkout.md), [frontend](frontend.md)  

```mermaid
flowchart LR
  currency["currency"]
  checkout["checkout"] -->|sync-call| currency
  frontend["frontend"] -->|sync-call| currency
```

## Purpose

Performs currency conversion for frontend and checkout, its declared callers. [derived: callers]

## If it fails

Price conversion in frontend pages and in the checkout order path fails. [derived: callers]

## Documentation

No documentation page names this component. [derived: docs source]
