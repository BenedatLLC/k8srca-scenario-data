# recommendation

**Kind:** service [derived: edges] [derived: callers]  
**Workload:** Deployment  
**Namespace:** otel-demo  
**Connects:** [flagd](flagd.md) via feature-flags (soft); [product-catalog](product-catalog.md) via sync-call  
**Called by:** [frontend](frontend.md)  

```mermaid
flowchart LR
  recommendation["recommendation"]
  frontend["frontend"] -->|sync-call| recommendation
  recommendation -.->|feature-flags| flagd["flagd"]
  recommendation -->|sync-call| product_catalog["product-catalog"]
```

## Purpose

Produces product recommendations for frontend, its only declared caller. [derived: callers]

Reads product data from product-catalog and feature-flag values from flagd. [derived: edges] [env: PRODUCT_CATALOG_ADDR] [env: FLAGD_HOST]

## If it fails

Frontend's recommendation calls fail; it is the only declared caller. [derived: callers]

## Connections

- **flagd** (feature-flags, soft): named by `FLAGD_HOST` (observed, k8stools)
- **product-catalog** (sync-call): named by `PRODUCT_CATALOG_ADDR` (observed, k8stools)

## Documentation

No documentation page names this component. [derived: docs source]
