# kafka

**Kind:** queue [derived: edges] [derived: callers]  
**Workload:** Deployment  
**Namespace:** otel-demo  
**Called by:** [accounting](accounting.md), [checkout](checkout.md), [fraud-detection](fraud-detection.md)  

```mermaid
flowchart LR
  kafka["kafka"]
  accounting["accounting"] -->|async-event| kafka
  checkout["checkout"] -->|async-event| kafka
  fraud_detection["fraud-detection"] -->|async-event| kafka
```

## Purpose

Carries the order messages published by checkout to the consumers accounting and fraud-detection. [derived: callers] [derived: edges]

## If it fails

Checkout cannot publish its order messages, and accounting and fraud-detection receive nothing to consume. [derived: callers] [derived: edges]

Accounting then has no input to record in postgresql, its only other declared dependency. [derived: edges]

## Documentation

No documentation page names this component. [derived: docs source]
