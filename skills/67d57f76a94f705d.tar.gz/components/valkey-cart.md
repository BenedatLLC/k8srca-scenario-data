# valkey-cart

**Kind:** datastore [derived: edges] [derived: callers]  
**Workload:** Deployment  
**Namespace:** otel-demo  
**Called by:** [cart](cart.md)  

```mermaid
flowchart LR
  valkey_cart["valkey-cart"]
  cart["cart"] -->|datastore| valkey_cart
```

## Purpose

Stores the cart state that cart reads and writes; cart is its only declared caller. [derived: callers] [derived: edges]

## If it fails

Cart has no declared alternative store, so its reads and writes fail, and through cart the frontend cart pages and the cart step of checkout are affected. [derived: callers] [derived: edges]

## Documentation

No documentation page names this component. [derived: docs source]
