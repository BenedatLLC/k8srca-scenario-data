# fraud-detection

**Kind:** service [derived: edges]  
**Workload:** Deployment  
**Namespace:** otel-demo  
**Connects:** [flagd](flagd.md) via feature-flags (soft); [kafka](kafka.md) via async-event  

```mermaid
flowchart LR
  fraud_detection["fraud-detection"]
  fraud_detection -.->|feature-flags| flagd["flagd"]
  fraud_detection -->|async-event| kafka["kafka"]
```

## Purpose

Consumes the order stream from kafka; it has no declared callers. [derived: edges] [derived: callers] [env: KAFKA_ADDR]

Reads feature-flag values from flagd. [derived: edges] [env: FLAGD_HOST]

## If it fails

No component calls it, so no request path breaks; the kafka order messages are no longer consumed by it. [derived: callers] [derived: edges]

## Connections

- **flagd** (feature-flags, soft): named by `FLAGD_HOST` (observed, k8stools)
- **kafka** (async-event): named by `KAFKA_ADDR` (observed, k8stools)

## Documentation

No documentation page names this component. [derived: docs source]
