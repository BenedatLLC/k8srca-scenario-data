# payment

**Kind:** service [derived: edges] [derived: callers]  
**Workload:** Deployment  
**Namespace:** otel-demo  
**Connects:** [flagd](flagd.md) via feature-flags (soft)  
**Called by:** [checkout](checkout.md)  

```mermaid
flowchart LR
  payment["payment"]
  checkout["checkout"] -->|sync-call| payment
  payment -.->|feature-flags| flagd["flagd"]
```

## Purpose

Processes payments for checkout, its only declared caller. [derived: callers]

Reads feature-flag values from flagd. [derived: edges] [env: FLAGD_HOST]

## If it fails

The payment step of checkout fails, interrupting the order path that frontend drives. [derived: callers] [derived: edges]

## Connections

- **flagd** (feature-flags, soft): named by `FLAGD_HOST` (observed, k8stools)

## Documentation

No documentation page names this component. [derived: docs source]
