# flagd

**Kind:** feature-flags [derived: callers] [derived: edges]  
**Workload:** Deployment  
**Namespace:** otel-demo  
**Called by:** [cart](cart.md), [checkout](checkout.md), [email](email.md), [fraud-detection](fraud-detection.md), [frontend](frontend.md), [frontend-proxy](frontend-proxy.md), [load-generator](load-generator.md), [payment](payment.md), [product-catalog](product-catalog.md), [recommendation](recommendation.md)  

```mermaid
flowchart LR
  flagd["flagd"]
  cart["cart"] -.->|feature-flags| flagd
  checkout["checkout"] -.->|feature-flags| flagd
  email["email"] -.->|feature-flags| flagd
  fraud_detection["fraud-detection"] -.->|feature-flags| flagd
  frontend["frontend"] -.->|feature-flags| flagd
  frontend_proxy["frontend-proxy"] -->|route| flagd
  load_generator["load-generator"] -.->|feature-flags| flagd
  payment["payment"] -.->|feature-flags| flagd
  product_catalog["product-catalog"] -.->|feature-flags| flagd
  recommendation["recommendation"] -.->|feature-flags| flagd
```

## Purpose

Serves feature-flag values to cart, checkout, email, fraud-detection, frontend, load-generator, payment, product-catalog and recommendation. [derived: callers]

Its endpoints are also exposed through a frontend-proxy route. [derived: callers] [derived: edges]

## If it fails

Its flag-reading callers carry on with default flag values, since those edges are ones the caller continues without. [derived: callers] [derived: edges]

The flagd paths served by frontend-proxy stop responding for users of that route, while the proxy's other paths keep serving. [derived: callers] [derived: edges]

## Documentation

No documentation page names this component. [derived: docs source]
