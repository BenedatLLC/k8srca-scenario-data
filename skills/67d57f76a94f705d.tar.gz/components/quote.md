# quote

**Kind:** service [derived: callers]  
**Workload:** Deployment  
**Namespace:** otel-demo  
**Called by:** [shipping](shipping.md)  

```mermaid
flowchart LR
  quote["quote"]
  shipping["shipping"] -->|sync-call| quote
```

## Purpose

Calculates shipping quotes for shipping, its only declared caller. [derived: callers]

## If it fails

Shipping's quote calls fail, which in turn affects the shipping estimates frontend and checkout request. [derived: callers] [derived: edges]

## Documentation

No documentation page names this component. [derived: docs source]
