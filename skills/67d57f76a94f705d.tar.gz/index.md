# System index

What this deployment is made of and how its parts connect. This wiki holds
no live state: for what is running now, ask the cluster.

## Overview

This is a microservice online-shop deployment: a frontend user interface backed by separate ad, cart, checkout, currency, email, payment, product-catalog, recommendation, shipping and quote services. [derived: edges] [derived: callers]

All externally reachable traffic arrives through frontend-proxy, which is the only component fronting frontend, image-provider, the flagd endpoints and the load-generator web interface. [derived: edges] [derived: callers]

The traffic itself is synthetic: load-generator drives requests at frontend-proxy, and no other caller of the proxy is declared. [derived: edges] [derived: callers]

The purchase path runs frontend to checkout, which fans out to cart, currency, email, payment, product-catalog and shipping, and publishes orders to kafka, where accounting and fraud-detection consume them. [derived: edges] [derived: callers]

Persistent and semi-persistent state lives in valkey-cart for shopping carts and postgresql for accounting, while flagd supplies feature-flag values to many components. [derived: edges] [derived: callers]

## Structure

```mermaid
flowchart LR
  subgraph group_datastore["datastore"]
    postgresql["postgresql"]
    valkey_cart["valkey-cart"]
  end
  subgraph group_feature_flags["feature-flags"]
    flagd["flagd"]
  end
  subgraph group_gateway["gateway"]
    frontend_proxy["frontend-proxy"]
  end
  subgraph group_load_generator["load-generator"]
    load_generator["load-generator"]
  end
  subgraph group_queue["queue"]
    kafka["kafka"]
  end
  subgraph group_service["service"]
    accounting["accounting"]
    ad["ad"]
    cart["cart"]
    checkout["checkout"]
    currency["currency"]
    email["email"]
    fraud_detection["fraud-detection"]
    image_provider["image-provider"]
    payment["payment"]
    product_catalog["product-catalog"]
    quote["quote"]
    recommendation["recommendation"]
    shipping["shipping"]
  end
  subgraph group_telemetry["telemetry"]
    otel_collector["otel-collector"]
  end
  subgraph group_ui["ui"]
    frontend["frontend"]
  end
  accounting -->|async-event| kafka
  accounting -->|datastore| postgresql
  cart -.->|feature-flags| flagd
  cart -->|datastore| valkey_cart
  checkout -->|sync-call| cart
  checkout -->|sync-call| currency
  checkout -->|sync-call| email
  checkout -.->|feature-flags| flagd
  checkout -->|async-event| kafka
  checkout -->|sync-call| payment
  checkout -->|sync-call| product_catalog
  checkout -->|sync-call| shipping
  email -.->|feature-flags| flagd
  fraud_detection -.->|feature-flags| flagd
  fraud_detection -->|async-event| kafka
  frontend -->|sync-call| ad
  frontend -->|sync-call| cart
  frontend -->|sync-call| checkout
  frontend -->|sync-call| currency
  frontend -.->|feature-flags| flagd
  frontend -->|sync-call| product_catalog
  frontend -->|sync-call| recommendation
  frontend -->|sync-call| shipping
  frontend_proxy -->|route| flagd
  frontend_proxy -->|route| frontend
  frontend_proxy -->|route| image_provider
  frontend_proxy -->|route| load_generator
  load_generator -.->|feature-flags| flagd
  load_generator -->|load| frontend_proxy
  payment -.->|feature-flags| flagd
  product_catalog -.->|feature-flags| flagd
  recommendation -.->|feature-flags| flagd
  recommendation -->|sync-call| product_catalog
  shipping -->|sync-call| quote
```

## Components

**datastore:** [postgresql](components/postgresql.md), [valkey-cart](components/valkey-cart.md)

**feature-flags:** [flagd](components/flagd.md)

**gateway:** [frontend-proxy](components/frontend-proxy.md)

**load-generator:** [load-generator](components/load-generator.md)

**queue:** [kafka](components/kafka.md)

**service:** [accounting](components/accounting.md), [ad](components/ad.md), [cart](components/cart.md), [checkout](components/checkout.md), [currency](components/currency.md), [email](components/email.md), [fraud-detection](components/fraud-detection.md), [image-provider](components/image-provider.md), [payment](components/payment.md), [product-catalog](components/product-catalog.md), [quote](components/quote.md), [recommendation](components/recommendation.md), [shipping](components/shipping.md)

**telemetry:** [otel-collector](components/otel-collector.md)

**ui:** [frontend](components/frontend.md)

Built from the sources in [sources.md](sources.md); what changed between
builds is in [log.md](log.md).
